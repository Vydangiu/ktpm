using System;
using System.Collections.Generic;

namespace LabNUnit.Core
{
    public class Radix
    {
        private int number;

        public Radix(int number)
        {
            if (number < 0)
                throw new ArgumentException("Incorrect Value");
            this.number = number;
        }

        public string Convert(int radix)
        {
            if (radix < 2 || radix > 16)
                throw new ArgumentException("Invalid Radix");

            if (number == 0) return "0";

            int n = number;
            List<string> result = new();

            while (n > 0)
            {
                int r = n % radix;
                result.Add(r < 10 ? r.ToString() : ((char)('A' + r - 10)).ToString());
                n /= radix;
            }

            result.Reverse();
            return string.Join("", result);
        }
    }
}

﻿namespace Lab.Core;

public class Class1
{

}

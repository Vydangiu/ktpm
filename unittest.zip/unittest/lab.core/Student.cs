using System.Collections.Generic;
using System.Linq;

namespace LabNUnit.Core
{
    public class Student
    {
        public string Id;
        public string Name;
        public double M1, M2, M3;

        public double Avg => (M1 + M2 + M3) / 3;

        public bool IsScholarship()
        {
            return Avg >= 8 && M1 >= 5 && M2 >= 5 && M3 >= 5;
        }
    }
}

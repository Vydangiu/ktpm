namespace LabNUnit.Core
{
    public class Point
    {
        public int X, Y;
        public Point(int x, int y) { X = x; Y = y; }
    }

    public class Rectangle
    {
        private Point topLeft;
        private Point bottomRight;

        public Rectangle(Point tl, Point br)
        {
            topLeft = tl;
            bottomRight = br;
        }

        public int Area()
        {
            return (bottomRight.X - topLeft.X) * (topLeft.Y - bottomRight.Y);
        }

        public bool Intersect(Rectangle r)
        {
            return !(r.bottomRight.X <= topLeft.X ||
                     r.topLeft.X >= bottomRight.X ||
                     r.topLeft.Y <= bottomRight.Y ||
                     r.bottomRight.Y >= topLeft.Y);
        }
    }
}

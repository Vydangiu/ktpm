using System;

namespace LabNUnit.Core
{
    public class MathUtils
    {
        public static double Power(double x, int n)
        {
            if (n == 0) return 1;
            if (n > 0) return x * Power(x, n - 1);
            return Power(x, n + 1) / x;
        }
    }
}

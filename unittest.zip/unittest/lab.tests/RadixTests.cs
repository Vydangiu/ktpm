using NUnit.Framework;
using LabNUnit.Core;
using System;

[TestFixture]
public class RadixTests
{
    [TestCase(10, 2, "1010")]
    [TestCase(10, 16, "A")]
    public void Convert_Valid_ReturnsCorrect(int number, int radix, string expected)
    {
        var r = new Radix(number);
        Assert.That(r.Convert(radix), Is.EqualTo(expected));
    }

    [Test]
    public void InvalidRadix_ThrowsException()
    {
        var r = new Radix(10);
        Assert.Throws<ArgumentException>(() => r.Convert(20));
    }
}

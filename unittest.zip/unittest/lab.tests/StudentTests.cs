using NUnit.Framework;
using LabNUnit.Core;

[TestFixture]
public class StudentTests
{
    [Test]
    public void Student_EligibleForScholarship_ReturnsTrue()
    {
        var s = new Student { M1 = 8, M2 = 9, M3 = 8 };
        Assert.That(s.IsScholarship(), Is.True);
    }

    [Test]
    public void Student_FailOneSubject_ReturnsFalse()
    {
        var s = new Student { M1 = 9, M2 = 4, M3 = 9 };
        Assert.That(s.IsScholarship(), Is.False);
    }
}

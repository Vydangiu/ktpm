using NUnit.Framework;
using LabNUnit.Core;
using System;
using System.Collections.Generic;

[TestFixture]
public class PolynomialTests
{
    [Test]
    public void Cal_ValidPolynomial_ReturnsCorrect()
    {
        var p = new Polynomial(2, new List<int> { 1, 2, 3 });
        Assert.That(p.Cal(2), Is.EqualTo(17));
    }

    [Test]
    public void Constructor_InvalidData_ThrowsException()
    {
        Assert.Throws<ArgumentException>(() =>
            new Polynomial(2, new List<int> { 1, 2 }));
    }
}

using NUnit.Framework;
using LabNUnit.Core;

[TestFixture]
public class RectangleTests
{
    [Test]
    public void Area_Correct()
    {
        var r = new Rectangle(new Point(0, 4), new Point(4, 0));
        Assert.That(r.Area(), Is.EqualTo(16));
    }

    [Test]
    public void Intersect_ReturnsTrue()
    {
        var r1 = new Rectangle(new Point(0, 4), new Point(4, 0));
        var r2 = new Rectangle(new Point(2, 3), new Point(6, -1));
        Assert.That(r1.Intersect(r2), Is.True);
    }
}

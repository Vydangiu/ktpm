using NUnit.Framework;
using LabNUnit.Core;

[TestFixture]
public class PowerTests
{
    [TestCase(2, 0, 1)]
    [TestCase(2, 3, 8)]
    [TestCase(2, -2, 0.25)]
    public void Power_Test(double x, int n, double expected)
    {
        Assert.That(MathUtils.Power(x, n), Is.EqualTo(expected).Within(0.0001));
    }
}

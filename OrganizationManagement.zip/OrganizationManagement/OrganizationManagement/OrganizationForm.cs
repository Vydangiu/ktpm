﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Windows.Forms;

namespace OrganizationManagement
{


    public class OrganizationForm : Form
    {
        // ===== CONNECTION STRING (SQL AUTH) =====
        private string connectionString =
    @"Data Source=DESKTOP-PFEO40A;Initial Catalog=OrganizationDB;User ID=sa;Password=ThaoVy;";


        TextBox txtOrgName = new TextBox();
        TextBox txtAddress = new TextBox();
        TextBox txtPhone = new TextBox();
        TextBox txtEmail = new TextBox();

        Button btnSave = new Button();
        Button btnBack = new Button();
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        Button btnDirector = new Button();

        public OrganizationForm()
        {
            Text = "Organization Management";
            Size = new Size(450, 350);
            StartPosition = FormStartPosition.CenterScreen;
            InitializeUI();
        }

        private void InitializeUI()
        {
            int lx = 30, tx = 180, y = 30, gap = 40;

            Controls.Add(CreateLabel("Organization Name (*)", lx, y));
            txtOrgName.Location = new Point(tx, y);
            txtOrgName.Width = 200;
            Controls.Add(txtOrgName);

            y += gap;
            Controls.Add(CreateLabel("Address", lx, y));
            txtAddress.Location = new Point(tx, y);
            txtAddress.Width = 200;
            Controls.Add(txtAddress);

            y += gap;
            Controls.Add(CreateLabel("Phone", lx, y));
            txtPhone.Location = new Point(tx, y);
            txtPhone.Width = 200;
            Controls.Add(txtPhone);

            y += gap;
            Controls.Add(CreateLabel("Email", lx, y));
            txtEmail.Location = new Point(tx, y);
            txtEmail.Width = 200;
            Controls.Add(txtEmail);

            y += 60;

            btnSave.Text = "Save";
            btnSave.Location = new Point(50, y);
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            btnBack.Text = "Back";
            btnBack.Location = new Point(170, y);
            btnBack.Click += (s, e) => Close();
            Controls.Add(btnBack);

            btnDirector.Text = "Director";
            btnDirector.Location = new Point(290, y);
            btnDirector.Enabled = false;
            btnDirector.Click += (s, e) =>
                MessageBox.Show($"Open Director for: {txtOrgName.Text}");
            Controls.Add(btnDirector);
        }

        private Label CreateLabel(string text, int x, int y)
        {
            return new Label { Text = text, Location = new Point(x, y + 3), AutoSize = true };
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtOrgName.Text))
            {
                MessageBox.Show("Organization Name is required");
                return false;
            }

            if (txtOrgName.Text.Length < 3 || txtOrgName.Text.Length > 255)
            {
                MessageBox.Show("Organization Name must be 3–255 characters");
                return false;
            }

            if (!string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                if (!txtPhone.Text.All(char.IsDigit))
                {
                    MessageBox.Show("Phone must contain only digits");
                    return false;
                }

                if (txtPhone.Text.Length < 9 || txtPhone.Text.Length > 12)
                {
                    MessageBox.Show("Phone must be 9–12 digits");
                    return false;
                }
            }

            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                try { new MailAddress(txtEmail.Text); }
                catch
                {
                    MessageBox.Show("Invalid email format");
                    return false;
                }
            }

            return true;
        }

        private bool IsOrgNameExists(string name)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    "SELECT COUNT(*) FROM ORGANIZATION WHERE OrgName=@OrgName", conn);
                cmd.Parameters.AddWithValue("@OrgName", name);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            if (IsOrgNameExists(txtOrgName.Text))
            {
                MessageBox.Show("Organization Name already exists");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO ORGANIZATION
                      (OrgName, Address, Phone, Email, CreatedDate)
                      VALUES (@OrgName,@Address,@Phone,@Email,GETDATE())", conn);

                cmd.Parameters.AddWithValue("@OrgName", txtOrgName.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Save successfully");
            btnDirector.Enabled = true;
        }

        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // OrganizationForm
            // 
            this.ClientSize = new System.Drawing.Size(768, 389);
            this.Name = "OrganizationForm";
            this.ResumeLayout(false);

        }
    }
}

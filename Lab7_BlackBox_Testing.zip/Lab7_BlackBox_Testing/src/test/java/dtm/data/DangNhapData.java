package dtm.data;

import org.testng.annotations.DataProvider;

public class DangNhapData {

    @DataProvider(name = "du_lieu_dang_nhap")
    public Object[][] getData() {
        return new Object[][]{
                {"standard_user", "secret_sauce", "THANH_CONG", "Login thành công với tài khoản hợp lệ"},
                {"locked_out_user", "secret_sauce", "BI_KHOA", "Tài khoản bị khóa"},
                {"abc_user", "123456", "SAI_THONG_TIN", "Username không tồn tại"},
                {"", "secret_sauce", "TRUONG_TRONG", "Username để trống"},
                {"standard_user", "", "TRUONG_TRONG", "Password để trống"},
                {"", "", "TRUONG_TRONG", "Username và Password đều trống"}
        };
    }
}
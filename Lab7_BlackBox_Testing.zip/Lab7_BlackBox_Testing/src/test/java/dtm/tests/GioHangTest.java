package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.CartPage;
import dtm.pages.CheckoutPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GioHangTest extends BaseTest {

    private InventoryPage inventoryPage;
    private CartPage cartPage;
    private CheckoutPage checkoutPage;

    @BeforeMethod(alwaysRun = true)
    public void chuanBiTest() {
        System.out.println("[GioHangTest] chuanBiTest BAT DAU");

        getDriver().get("https://www.saucedemo.com");

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.dangNhap("standard_user", "secret_sauce");

        inventoryPage = new InventoryPage(getDriver());
        cartPage = new CartPage(getDriver());
        checkoutPage = new CheckoutPage(getDriver());

        System.out.println("[GioHangTest] URL sau login = " + getDriver().getCurrentUrl());

        Assert.assertTrue(
                inventoryPage.isDangOTrangSanPham(),
                "Không đăng nhập được trước khi chạy test."
        );

        System.out.println("[GioHangTest] chuanBiTest KET THUC");
    }


    @Test(groups = {"smoke"}, description = "TC_CART_001: Thêm 1 sản phẩm – badge = 1")
    public void themMotSanPham() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");

        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 1, "Badge phải bằng 1");

        inventoryPage.vaoGioHang();
        Assert.assertEquals(cartPage.laySoLuongSanPhamTrongGio(), 1, "Giỏ hàng phải có 1 sản phẩm");
        Assert.assertTrue(
                cartPage.layDanhSachTenSanPhamTrongGio().contains("Sauce Labs Backpack"),
                "Giỏ hàng phải chứa Sauce Labs Backpack"
        );
    }

    @Test(groups = {"smoke"}, description = "TC_CART_002: Thêm 3 sản phẩm – badge = 3")
    public void them3SanPham() {
        inventoryPage.themNSanPhamDauTien(3);

        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 3, "Badge phải bằng 3");

        inventoryPage.vaoGioHang();
        Assert.assertEquals(cartPage.laySoLuongSanPhamTrongGio(), 3, "Giỏ hàng phải có 3 sản phẩm");
    }

    @Test(groups = {"regression"}, description = "TC_CART_003: Xoá hết – giỏ trống")
    public void xoaHetSanPham() {
        inventoryPage.themNSanPhamDauTien(3);
        inventoryPage.vaoGioHang();

        cartPage.xoaTatCaSanPham();

        Assert.assertTrue(cartPage.isCartEmpty(), "Giỏ hàng phải trống sau khi xoá hết");
    }

    @Test(groups = {"regression"}, description = "TC_CART_004: Sort giá tăng dần – đúng thứ tự")
    public void sortGiaTangDan() {
        inventoryPage.sortSanPham("lohi");

        List<Double> actual = inventoryPage.layDanhSachGiaSanPham();
        List<Double> expected = new ArrayList<>(actual);
        Collections.sort(expected);

        Assert.assertEquals(actual, expected, "Danh sách giá phải tăng dần");
    }

    @Test(groups = {"regression"}, description = "TC_CART_005: Sort giá giảm dần – đúng thứ tự")
    public void sortGiaGiamDan() {
        inventoryPage.sortSanPham("hilo");

        List<Double> actual = inventoryPage.layDanhSachGiaSanPham();
        List<Double> expected = new ArrayList<>(actual);
        expected.sort(Collections.reverseOrder());

        Assert.assertEquals(actual, expected, "Danh sách giá phải giảm dần");
    }

    @Test(groups = {"regression"}, description = "TC_CART_006: Sort tên A->Z – đúng thứ tự")
    public void sortTenAZ() {
        inventoryPage.sortSanPham("az");

        List<String> actual = inventoryPage.layDanhSachTenSanPham();
        List<String> expected = new ArrayList<>(actual);
        Collections.sort(expected);

        Assert.assertEquals(actual, expected, "Danh sách tên phải tăng dần A->Z");
    }

    @Test(groups = {"regression"}, description = "TC_CART_007: Sort tên Z->A – đúng thứ tự")
    public void sortTenZA() {
        inventoryPage.sortSanPham("za");

        List<String> actual = inventoryPage.layDanhSachTenSanPham();
        List<String> expected = new ArrayList<>(actual);
        expected.sort(Collections.reverseOrder());

        Assert.assertEquals(actual, expected, "Danh sách tên phải giảm dần Z->A");
    }

    @Test(groups = {"regression"}, description = "TC_CART_008: Continue Shopping từ cart")
    public void continueShoppingTuCart() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();

        cartPage.continueShopping();

        Assert.assertTrue(inventoryPage.isDangOTrangSanPham(), "Phải quay lại trang inventory");
    }

    @Test(groups = {"regression"}, description = "TC_CART_009: Checkout lỗi khi trống First Name")
    public void checkoutTrongFirstName() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("", "Nguyen", "70000");
        checkoutPage.clickContinue();

        Assert.assertNotNull(checkoutPage.layThongBaoLoi(), "Phải hiển thị lỗi");
    }

    @Test(groups = {"regression"}, description = "TC_CART_010: Checkout lỗi khi trống Last Name")
    public void checkoutTrongLastName() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "", "70000");
        checkoutPage.clickContinue();

        Assert.assertNotNull(checkoutPage.layThongBaoLoi(), "Phải hiển thị lỗi");
    }

    @Test(groups = {"regression"}, description = "TC_CART_011: Checkout lỗi khi trống Zip Code")
    public void checkoutTrongZip() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "");
        checkoutPage.clickContinue();

        Assert.assertNotNull(checkoutPage.layThongBaoLoi(), "Phải hiển thị lỗi");
    }

    @Test(groups = {"smoke"}, description = "TC_CART_012: Checkout hợp lệ")
    public void checkoutHopLe() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();

        Assert.assertTrue(checkoutPage.isDangOCheckoutStep2(), "Phải chuyển sang step 2");
    }

    @Test(groups = {"regression"}, description = "TC_CART_013: Cancel ở Step 1")
    public void cancelStep1() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.clickCancelStep1();

        Assert.assertTrue(cartPage.isDangOTrangCart(), "Phải quay về cart");
    }

    @Test(groups = {"regression"}, description = "TC_CART_014: Cancel ở Step 2")
    public void cancelStep2() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();
        checkoutPage.clickCancelStep2();

        Assert.assertTrue(inventoryPage.isDangOTrangSanPham(), "Phải quay về inventory");
    }

    @Test(groups = {"smoke"}, description = "TC_CART_015: Finish checkout thành công")
    public void finishCheckoutThanhCong() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();
        checkoutPage.clickFinish();

        Assert.assertTrue(checkoutPage.isOrderComplete(), "Đơn hàng phải hoàn tất");
    }

    @Test(groups = {"regression"}, description = "TC_CART_016: Back Home sau khi hoàn tất")
    public void backHomeSauKhiHoanTat() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();
        checkoutPage.clickFinish();
        checkoutPage.clickBackHome();

        Assert.assertTrue(inventoryPage.isDangOTrangSanPham(), "Phải quay về inventory");
    }

    @Test(groups = {"regression"}, description = "TC_CART_017: Giỏ hàng reset sau khi hoàn tất")
    public void gioHangResetSauKhiHoanTat() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.themSanPhamTheoTen("Sauce Labs Bike Light");
        inventoryPage.vaoGioHang();
        cartPage.checkout();

        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();
        checkoutPage.clickFinish();
        checkoutPage.clickBackHome();

        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 0, "Badge phải về 0 sau khi hoàn tất");
    }

    @Test(groups = {"regression"}, description = "TC_CART_018: Kiểm tra tổng tiền chính xác")
    public void kiemTraTongTien() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.themSanPhamTheoTen("Sauce Labs Bike Light");
        inventoryPage.themSanPhamTheoTen("Sauce Labs Bolt T-Shirt");

        inventoryPage.vaoGioHang();

        List<Double> giaTrongGio = cartPage.layDanhSachGiaSanPhamTrongGio();
        double tongGiaTuTinh = 0.0;
        for (Double gia : giaTrongGio) {
            tongGiaTuTinh += gia;
        }

        cartPage.checkout();
        checkoutPage.nhapThongTin("An", "Nguyen", "70000");
        checkoutPage.clickContinue();

        double itemTotal = checkoutPage.layItemTotal();
        double tax = checkoutPage.layTax();
        double total = checkoutPage.layTotal();

        Assert.assertEquals(itemTotal, tongGiaTuTinh, 0.01, "Item total không đúng");
        Assert.assertEquals(tax, itemTotal * 0.08, 0.01, "Tax không đúng 8%");
        Assert.assertEquals(total, itemTotal + tax, 0.01, "Total không đúng");
    }
}
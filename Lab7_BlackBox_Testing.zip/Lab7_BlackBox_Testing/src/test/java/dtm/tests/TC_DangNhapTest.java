package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_DangNhapTest extends BaseTest {

    @Test(
            dataProvider = "du_lieu_dang_nhap",
            dataProviderClass = DangNhapData.class,
            description = "Kiểm thử đăng nhập với nhiều bộ dữ liệu"
    )
    public void kiemThuDangNhap(String username, String password,
                                String ketQuaMongDoi, String moTa) {

        getDriver().get("https://www.saucedemo.com");

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.dangNhap(username, password);

        String error = loginPage.layThongBaoLoi();

        System.out.println("========== TEST DATA ==========");
        System.out.println("Mo ta: " + moTa);
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        System.out.println("Ket qua mong doi: " + ketQuaMongDoi);
        System.out.println("URL hien tai: " + getDriver().getCurrentUrl());
        System.out.println("Error message: " + error);
        System.out.println("================================");

        switch (ketQuaMongDoi) {
            case "THANH_CONG":
                Assert.assertTrue(
                        loginPage.isDangOTrangSanPham(),
                        "FAIL - " + moTa + ": Không chuyển sang trang sản phẩm"
                );
                break;

            case "BI_KHOA":
            case "TRUONG_TRONG":
            case "SAI_THONG_TIN":
                Assert.assertNotNull(
                        error,
                        "FAIL - " + moTa + ": Không hiển thị thông báo lỗi"
                );
                Assert.assertFalse(
                        loginPage.isDangOTrangSanPham(),
                        "FAIL - " + moTa + ": Không được đăng nhập thành công"
                );
                break;

            default:
                Assert.fail("ketQuaMongDoi không hợp lệ: " + ketQuaMongDoi);
        }
    }
}
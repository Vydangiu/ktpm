package dtm.tests;

import dtm.base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SmokeTest extends BaseTest {

    @Test(groups = {"smoke"})
    public void moTrangSauceDemo() {

        getDriver().get("https://www.saucedemo.com");

        String title = getDriver().getTitle();

        Assert.assertTrue(title.toLowerCase().contains("swag"));
    }

}
package dtm.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class BaseTest {

    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    @BeforeMethod(alwaysRun = true)
    public void setUp(Method method) {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        WebDriver driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        driverThreadLocal.set(driver);

        System.out.println("[BaseTest] setUp dang chay cho test: " + method.getName());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        WebDriver driver = getDriver();

        if (driver != null) {
            if (result.getStatus() == ITestResult.FAILURE) {
                takeScreenshot(result.getName(), driver);
            }

            driver.quit();
            driverThreadLocal.remove();
        }
    }

    public WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver == null) {
            throw new IllegalStateException("Driver chưa được khởi tạo. Kiểm tra lại @BeforeMethod trong BaseTest.");
        }
        return driver;
    }

    private void takeScreenshot(String testName, WebDriver driver) {
        try {
            File folder = new File("screenshots");
            if (!folder.exists()) {
                folder.mkdirs();
            }

            String timeStamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));

            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File(folder, testName + "_" + timeStamp + ".png");

            FileHandler.copy(srcFile, destFile);
            System.out.println("[SCREENSHOT SAVED] " + destFile.getAbsolutePath());

        } catch (IOException e) {
            System.out.println("[SCREENSHOT ERROR] " + e.getMessage());
        }
    }
}
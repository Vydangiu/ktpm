package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CheckoutPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Step 1
    private By firstNameField = By.id("first-name");
    private By lastNameField = By.id("last-name");
    private By postalCodeField = By.id("postal-code");
    private By continueButton = By.id("continue");
    private By cancelButton = By.id("cancel");
    private By errorMessage = By.cssSelector("h3[data-test='error']");

    // Step 2
    private By itemTotalLabel = By.className("summary_subtotal_label");
    private By taxLabel = By.className("summary_tax_label");
    private By totalLabel = By.className("summary_total_label");
    private By finishButton = By.id("finish");

    // Complete
    private By completeHeader = By.className("complete-header");
    // Nút Back Home trên SauceDemo hiện có thể là id này hoặc nút text "Back Home"
    private By backHomeButton = By.id("back-to-products");
    private By backHomeButtonFallback = By.xpath("//button[normalize-space()='Back Home']");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void nhapFirstName(String firstName) {
        WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField));
        e.clear();
        if (firstName != null) {
            e.sendKeys(firstName);
        }
    }

    public void nhapLastName(String lastName) {
        WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameField));
        e.clear();
        if (lastName != null) {
            e.sendKeys(lastName);
        }
    }

    public void nhapZipCode(String zip) {
        WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(postalCodeField));
        e.clear();
        if (zip != null) {
            e.sendKeys(zip);
        }
    }

    public void nhapThongTin(String firstName, String lastName, String zip) {
        nhapFirstName(firstName);
        nhapLastName(lastName);
        nhapZipCode(zip);
    }

    public void clickContinue() {
        wait.until(ExpectedConditions.elementToBeClickable(continueButton)).click();
    }

    public void clickCancelStep1() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton)).click();
    }

    public void clickCancelStep2() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton)).click();
    }

    public String layThongBaoLoi() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage)).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public double layItemTotal() {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(itemTotalLabel)).getText();
        return tachSo(text);
    }

    public double layTax() {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(taxLabel)).getText();
        return tachSo(text);
    }

    public double layTotal() {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(totalLabel)).getText();
        return tachSo(text);
    }

    private double tachSo(String text) {
        String so = text.replaceAll("[^0-9.]", "");
        return Double.parseDouble(so);
    }

    public void clickFinish() {
        wait.until(ExpectedConditions.elementToBeClickable(finishButton)).click();
    }

    public boolean isDangOCheckoutStep1() {
        try {
            wait.until(ExpectedConditions.urlContains("checkout-step-one.html"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isDangOCheckoutStep2() {
        try {
            wait.until(ExpectedConditions.urlContains("checkout-step-two.html"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isOrderComplete() {
        try {
            wait.until(ExpectedConditions.urlContains("checkout-complete.html"));
            String header = wait.until(ExpectedConditions.visibilityOfElementLocated(completeHeader)).getText();
            return header.toLowerCase().contains("thank you");
        } catch (Exception e) {
            return false;
        }
    }

    public void clickBackHome() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(backHomeButton)).click();
        } catch (Exception e) {
            wait.until(ExpectedConditions.elementToBeClickable(backHomeButtonFallback)).click();
        }
    }
}
package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    private By userNameField = By.id("user-name");
    private By passwordField = By.id("password");
    private By loginButton = By.id("login-button");
    private By errorMessage = By.cssSelector("h3[data-test='error']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }


    public void nhapUsername(String username) {
        driver.findElement(userNameField).clear();
        if (username != null) {
            driver.findElement(userNameField).sendKeys(username);
        }
    }

    public void nhapPassword(String password) {
        driver.findElement(passwordField).clear();
        if (password != null) {
            driver.findElement(passwordField).sendKeys(password);
        }
    }

    public void clickDangNhap() {
        driver.findElement(loginButton).click();
    }

    public void dangNhap(String user, String pass) {
        nhapUsername(user);
        nhapPassword(pass);
        clickDangNhap();
    }

    public String layThongBaoLoi() {
        try {
            return driver.findElement(errorMessage).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public boolean isDangOTrangSanPham() {
        return driver.getCurrentUrl().contains("inventory.html");
    }


}
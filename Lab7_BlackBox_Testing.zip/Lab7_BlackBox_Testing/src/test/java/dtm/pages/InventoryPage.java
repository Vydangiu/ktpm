package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

public class InventoryPage {

    private WebDriver driver;

    private By sortDropdown = By.className("product_sort_container");
    private By inventoryItems = By.className("inventory_item");
    private By productNames = By.className("inventory_item_name");
    private By productPrices = By.className("inventory_item_price");
    private By cartBadge = By.className("shopping_cart_badge");
    private By cartLink = By.className("shopping_cart_link");

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
    }

    public void themSanPhamTheoTen(String tenSanPham) {
        List<WebElement> items = driver.findElements(inventoryItems);

        for (WebElement item : items) {
            String ten = item.findElement(By.className("inventory_item_name")).getText();
            if (ten.equalsIgnoreCase(tenSanPham)) {
                WebElement button = item.findElement(By.tagName("button"));
                button.click();
                return;
            }
        }

        throw new NoSuchElementException("Không tìm thấy sản phẩm: " + tenSanPham);
    }

    public void xoaSanPhamTheoTen(String tenSanPham) {
        List<WebElement> items = driver.findElements(inventoryItems);

        for (WebElement item : items) {
            String ten = item.findElement(By.className("inventory_item_name")).getText();
            if (ten.equalsIgnoreCase(tenSanPham)) {
                WebElement button = item.findElement(By.tagName("button"));
                button.click();
                return;
            }
        }

        throw new NoSuchElementException("Không tìm thấy sản phẩm để xoá: " + tenSanPham);
    }

    public void themNSanPhamDauTien(int n) {
        List<WebElement> items = driver.findElements(inventoryItems);

        if (n > items.size()) {
            throw new IllegalArgumentException("Số lượng yêu cầu lớn hơn số sản phẩm hiện có.");
        }

        for (int i = 0; i < n; i++) {
            WebElement button = items.get(i).findElement(By.tagName("button"));
            button.click();
        }
    }

    public int laySoLuongBadge() {
        try {
            return Integer.parseInt(driver.findElement(cartBadge).getText());
        } catch (Exception e) {
            return 0;
        }
    }

    public void sortSanPham(String option) {
        Select select = new Select(driver.findElement(sortDropdown));
        select.selectByValue(option); // az, za, lohi, hilo
    }

    public List<String> layDanhSachTenSanPham() {
        List<String> ds = new ArrayList<>();
        List<WebElement> names = driver.findElements(productNames);

        for (WebElement e : names) {
            ds.add(e.getText().trim());
        }

        return ds;
    }

    public List<Double> layDanhSachGiaSanPham() {
        List<Double> ds = new ArrayList<>();
        List<WebElement> prices = driver.findElements(productPrices);

        for (WebElement e : prices) {
            String gia = e.getText().replace("$", "").trim();
            ds.add(Double.parseDouble(gia));
        }

        return ds;
    }

    public void vaoGioHang() {
        driver.findElement(cartLink).click();
    }

    public boolean isDangOTrangSanPham() {
        return driver.getCurrentUrl().contains("inventory.html");
    }
}
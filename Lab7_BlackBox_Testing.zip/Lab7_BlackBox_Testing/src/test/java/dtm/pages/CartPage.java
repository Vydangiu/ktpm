package dtm.pages;

import org.openqa.selenium.*;

import java.util.ArrayList;
import java.util.List;

public class CartPage {

    private WebDriver driver;

    private By cartItems = By.className("cart_item");
    private By itemNames = By.className("inventory_item_name");
    private By itemPrices = By.className("inventory_item_price");
    private By continueShoppingButton = By.id("continue-shopping");
    private By checkoutButton = By.id("checkout");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public int laySoLuongSanPhamTrongGio() {
        return driver.findElements(cartItems).size();
    }

    public List<String> layDanhSachTenSanPhamTrongGio() {
        List<String> ds = new ArrayList<>();
        List<WebElement> names = driver.findElements(itemNames);

        for (WebElement e : names) {
            ds.add(e.getText().trim());
        }

        return ds;
    }

    public List<Double> layDanhSachGiaSanPhamTrongGio() {
        List<Double> ds = new ArrayList<>();
        List<WebElement> prices = driver.findElements(itemPrices);

        for (WebElement e : prices) {
            String gia = e.getText().replace("$", "").trim();
            ds.add(Double.parseDouble(gia));
        }

        return ds;
    }

    public void xoaSanPhamTheoTen(String tenSanPham) {
        List<WebElement> items = driver.findElements(cartItems);

        for (WebElement item : items) {
            String ten = item.findElement(By.className("inventory_item_name")).getText();
            if (ten.equalsIgnoreCase(tenSanPham)) {
                item.findElement(By.tagName("button")).click();
                return;
            }
        }

        throw new NoSuchElementException("Không tìm thấy sản phẩm trong giỏ: " + tenSanPham);
    }

    public void xoaTatCaSanPham() {
        while (driver.findElements(cartItems).size() > 0) {
            driver.findElements(cartItems).get(0).findElement(By.tagName("button")).click();
        }
    }

    public boolean isCartEmpty() {
        return laySoLuongSanPhamTrongGio() == 0;
    }

    public void continueShopping() {
        driver.findElement(continueShoppingButton).click();
    }

    public void checkout() {
        driver.findElement(checkoutButton).click();
    }

    public boolean isDangOTrangCart() {
        return driver.getCurrentUrl().contains("cart.html");
    }
}